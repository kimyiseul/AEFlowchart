# Flowmate

Type your idea first, convert the idea to the symobol of flowchart. It's fast and simaple.

## Special Thanks to

- tadija (https://github.com/tadija/aeflowchart)

The main concept of Flowmate is inspired by him. In addtion, the connetion line is use his code almost.

- utmo (https://github.com/utom/) and marcosvidal (https://github.com/marcosvidal)

When I stared to develop my own plugin, there code is great examples. 